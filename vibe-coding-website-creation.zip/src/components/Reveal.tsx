import { type ElementType, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { useReveal } from "../hooks/useReveal";

interface RevealProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: ElementType;
}

export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: RevealProps) {
  const ref = useReveal<HTMLDivElement>();

  return (
    <Tag
      ref={ref}
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      style={{ transitionDelay: `${delay}ms` } as any}
      className={cn("reveal", className)}
    >
      {children}
    </Tag>
  );
}
