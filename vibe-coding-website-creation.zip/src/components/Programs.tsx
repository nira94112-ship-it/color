import { useState } from "react";
import { Reveal } from "./Reveal";

const PROGRAMS = [
  {
    id: "frontend",
    name: "Front-End Intensive",
    tag: "Most popular",
    level: "Beginner → Job-ready",
    duration: "12 weeks",
    blurb:
      "Build interfaces people actually love. Modern React, design systems, and the craft of turning designs into pixels.",
    stack: ["React", "TypeScript", "Tailwind"],
    highlights: [
      "Ship 4 portfolio-grade projects",
      "Weekly live code reviews",
      "Figma → production workflow",
    ],
  },
  {
    id: "fullstack",
    name: "Full-Stack Engineering",
    tag: "Career switch",
    level: "Intermediate → Employed",
    duration: "16 weeks",
    blurb:
      "Own features end to end. Databases, APIs, auth, deployment — the entire loop, taught by engineers who run it daily.",
    stack: ["Next.js", "Node", "PostgreSQL"],
    highlights: [
      "Capstone: a real SaaS product",
      "1:1 senior pairing, 3× / week",
      "Mock interviews + referrals",
    ],
  },
  {
    id: "aidev",
    name: "AI-Native Development",
    tag: "Emerging",
    level: "Any level → 10× output",
    duration: "8 weeks",
    blurb:
      "Ship faster than ever. Prompt engineering, agents, evals, and how to keep AI-generated code correct, secure, and yours.",
    stack: ["LLMs", "Agents", "Evals"],
    highlights: [
      "Build a working AI product",
      "Production prompt architecture",
      "Responsible AI practices",
    ],
  },
];

export function Programs() {
  const [active, setActive] = useState("frontend");
  const current = PROGRAMS.find((p) => p.id === active)!;

  return (
    <section id="programs" className="relative px-5 py-24 sm:px-8 sm:py-32">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="mb-14 max-w-2xl">
            <span className="font-mono text-sm font-medium uppercase tracking-widest text-acid">
              // Programs
            </span>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
              Pick your path. <span className="text-bone-dim">We'll handle the rest.</span>
            </h2>
          </div>
        </Reveal>

        {/* Selector tabs */}
        <Reveal delay={100}>
          <div className="mb-10 flex flex-wrap gap-2">
            {PROGRAMS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setActive(p.id)}
                className={`rounded-full border px-5 py-2.5 text-sm font-semibold transition-all duration-300 ${
                  active === p.id
                    ? "border-acid bg-acid text-ink"
                    : "border-line bg-ink-2 text-bone-dim hover:border-bone-dim hover:text-bone"
                }`}
              >
                {p.name}
              </button>
            ))}
          </div>
        </Reveal>

        {/* Detail panel */}
        <Reveal key={active} delay={120}>
          <div className="grid grid-cols-1 gap-8 rounded-3xl border border-line bg-ink-2/60 p-7 sm:p-10 lg:grid-cols-5">
            <div className="lg:col-span-3">
              <div className="mb-4 flex items-center gap-3">
                <span className="rounded-md bg-acid/15 px-2.5 py-1 font-mono text-xs font-bold text-acid">
                  {current.tag}
                </span>
                <span className="font-mono text-xs text-bone-dim">
                  {current.level}
                </span>
              </div>
              <h3 className="font-display text-3xl font-bold sm:text-4xl">
                {current.name}
              </h3>
              <p className="mt-4 max-w-lg text-lg leading-relaxed text-bone-dim">
                {current.blurb}
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {current.stack.map((s) => (
                  <span
                    key={s}
                    className="rounded-md border border-line bg-ink px-3 py-1.5 font-mono text-sm text-bone"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2">
              <div className="rounded-2xl border border-line bg-ink p-6">
                <div className="mb-5 flex items-baseline justify-between">
                  <span className="font-mono text-sm text-bone-dim">Duration</span>
                  <span className="font-display text-2xl font-bold">
                    {current.duration}
                  </span>
                </div>
                <ul className="space-y-3.5">
                  {current.highlights.map((h) => (
                    <li key={h} className="flex items-start gap-3">
                      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-acid text-ink">
                        <svg
                          viewBox="0 0 24 24"
                          fill="none"
                          className="h-3.5 w-3.5"
                          stroke="currentColor"
                          strokeWidth={3.5}
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M20 6 9 17l-5-5" />
                        </svg>
                      </span>
                      <span className="text-[15px] text-bone">{h}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href="#apply"
                  className="mt-7 flex items-center justify-center gap-2 rounded-full bg-acid px-5 py-3.5 text-sm font-bold text-ink transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_30px_-6px_var(--color-acid)]"
                >
                  Apply to {current.name.split(" ")[0]} →
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
