import { useEffect, useState } from "react";
import { Reveal } from "./Reveal";

const TESTIMONIALS = [
  {
    quote:
      "I went from tutorial hell to a full-time engineering offer in 14 weeks. The mentor pairing changed everything — I finally had someone who'd tell me my code was wrong.",
    name: "Maya Okonkwo",
    role: "Frontend Engineer @ Linear",
    init: "MO",
    color: "bg-ember",
  },
  {
    quote:
      "The AI-Native track is unlike anything else. I'm now shipping features in days that used to take me weeks. It's not magic — it's just taught really well.",
    name: "Daniel Reyes",
    role: "Indie Hacker",
    init: "DR",
    color: "bg-acid",
  },
  {
    quote:
      "Best career decision I've made. The cohort became my network, and three of us shipped a product together after graduating. This place builds people, not just coders.",
    name: "Priya Nair",
    role: "Full-Stack Dev @ Stripe",
    init: "PN",
    color: "bg-sky-500",
  },
  {
    quote:
      "As a career switcher I was terrified. VIPE met me where I was and never let me settle. Six months later I'm leading a team. Worth every cent.",
    name: "Tom Havel",
    role: "Engineering Manager @ Vercel",
    init: "TH",
    color: "bg-fuchsia-500",
  },
];

export function Testimonials() {
  const [i, setI] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setI((v) => (v + 1) % TESTIMONIALS.length), 6000);
    return () => clearInterval(id);
  }, []);

  const t = TESTIMONIALS[i];

  return (
    <section className="relative overflow-hidden border-y border-line bg-ink-2/40 px-5 py-24 sm:px-8 sm:py-32">
      <div className="pointer-events-none absolute left-1/2 top-0 h-64 w-64 -translate-x-1/2 rounded-full bg-acid/10 blur-[120px]" />
      <div className="relative mx-auto max-w-4xl text-center">
        <Reveal>
          <span className="font-mono text-sm font-medium uppercase tracking-widest text-acid">
            // Outcomes
          </span>
          <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Loved by builders.
          </h2>
        </Reveal>

        <Reveal key={i} delay={100}>
          <div className="mt-12">
            <svg
              viewBox="0 0 24 24"
              className="mx-auto mb-6 h-10 w-10 text-acid/40"
              fill="currentColor"
            >
              <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
            </svg>
            <blockquote className="font-display text-2xl font-medium leading-snug text-balance sm:text-3xl">
              {t.quote}
            </blockquote>
            <div className="mt-8 flex items-center justify-center gap-3.5">
              <span
                className={`grid h-12 w-12 place-items-center rounded-full ${t.color} font-bold text-ink`}
              >
                {t.init}
              </span>
              <div className="text-left">
                <div className="font-display font-bold">{t.name}</div>
                <div className="text-sm text-bone-dim">{t.role}</div>
              </div>
            </div>
          </div>
        </Reveal>

        {/* Dots */}
        <div className="mt-10 flex justify-center gap-2">
          {TESTIMONIALS.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setI(idx)}
              aria-label={`Testimonial ${idx + 1}`}
              className={`h-2 rounded-full transition-all duration-300 ${
                idx === i ? "w-8 bg-acid" : "w-2 bg-line hover:bg-bone-dim"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
