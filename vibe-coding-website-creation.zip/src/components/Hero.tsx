import { useEffect, useRef, useState } from "react";
import { Reveal } from "./Reveal";

const TYPED_LINES = [
  "ship a real product in 12 weeks.",
  "build with senior mentors daily.",
  "master AI-assisted development.",
  "launch something the world can use.",
];

function useTypewriter(lines: string[], speed = 55, pause = 1800) {
  const [text, setText] = useState("");
  const [lineIndex, setLineIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = lines[lineIndex];

    let timeout: ReturnType<typeof setTimeout>;

    if (!deleting && text === current) {
      timeout = setTimeout(() => setDeleting(true), pause);
    } else if (deleting && text === "") {
      setDeleting(false);
      setLineIndex((i) => (i + 1) % lines.length);
    } else {
      timeout = setTimeout(() => {
        setText((prev) =>
          deleting
            ? current.slice(0, Math.max(0, prev.length - 1))
            : current.slice(0, prev.length + 1),
        );
      }, deleting ? speed / 2 : speed);
    }

    return () => clearTimeout(timeout);
  }, [text, deleting, lineIndex, lines, speed, pause]);

  return text;
}

export function Hero() {
  const typed = useTypewriter(TYPED_LINES);
  const [cursorVisible, setCursorVisible] = useState(true);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = setInterval(() => setCursorVisible((v) => !v), 530);
    return () => clearInterval(id);
  }, []);

  return (
    <section
      id="top"
      ref={ref}
      className="relative flex min-h-screen items-center overflow-hidden pt-16"
    >
      {/* Background layers */}
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-[0.5]" />
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-40 top-1/4 h-96 w-96 animate-float rounded-full bg-acid/10 blur-[120px]" />
        <div className="absolute -right-32 bottom-0 h-[28rem] w-[28rem] rounded-full bg-ember/10 blur-[140px]" />
      </div>

      <div className="relative mx-auto grid w-full max-w-7xl grid-cols-1 items-center gap-12 px-5 py-20 sm:px-8 lg:grid-cols-2 lg:gap-8">
        {/* Left: copy */}
        <div className="max-w-xl">
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-line bg-ink-2 px-3.5 py-1.5 text-xs font-medium text-bone-dim">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-acid opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-acid" />
              </span>
              Cohort 07 · Applications open
            </span>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="mt-6 font-display text-5xl font-extrabold leading-[1.02] tracking-tight text-balance sm:text-6xl lg:text-7xl">
              Code at the
              <br />
              <span className="relative">
                <span className="relative z-10 text-acid speed">speed of thought</span>
                <span className="absolute inset-x-0 bottom-2 z-0 h-3 -rotate-1 bg-acid/15 sm:bottom-3" />
              </span>
              .
            </h1>
          </Reveal>

          <Reveal delay={160}>
            <p className="mt-6 text-lg leading-relaxed text-bone-dim text-balance">
              VIPE is an elite, mentor-led coding studio. We pair you with
              engineers who ship for a living — so you stop watching tutorials
              and start
              <span className="font-semibold text-bone">
                {" "}
                {typed}
                <span
                  className={`ml-0.5 inline-block h-5 w-[3px] translate-y-1 bg-acid align-middle ${
                    cursorVisible ? "opacity-100" : "opacity-0"
                  }`}
                />
              </span>
            </p>
          </Reveal>

          <Reveal delay={240}>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <a
                href="#apply"
                className="group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full bg-acid px-7 py-4 text-base font-bold text-ink transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_0_40px_-6px_var(--color-acid)]"
              >
                Start your build
                <span className="transition-transform duration-300 group-hover:translate-x-1">
                  →
                </span>
              </a>
              <a
                href="#programs"
                className="inline-flex items-center justify-center gap-2 rounded-full border border-line bg-ink-2 px-7 py-4 text-base font-semibold text-bone transition-all duration-300 hover:border-acid hover:text-acid"
              >
                Explore programs
              </a>
            </div>
          </Reveal>

          <Reveal delay={320}>
            <div className="mt-10 flex items-center gap-6 text-sm text-bone-dim">
              <div className="flex -space-x-2.5">
                {[
                  "bg-ember",
                  "bg-acid",
                  "bg-sky-500",
                  "bg-fuchsia-500",
                  "bg-amber-400",
                ].map((c, i) => (
                  <span
                    key={i}
                    className={`grid h-9 w-9 place-items-center rounded-full border-2 border-ink ${c} text-[11px] font-bold text-ink`}
                  >
                    {String.fromCharCode(65 + i)}
                  </span>
                ))}
              </div>
              <p>
                <span className="font-bold text-bone">1,200+</span> builders
                shipped since 2021
              </p>
            </div>
          </Reveal>
        </div>

        {/* Right: terminal */}
        <Reveal delay={200} className="lg:justify-self-end">
          <div className="relative w-full max-w-lg">
            <div className="absolute -inset-px rounded-2xl bg-gradient-to-br from-acid/40 via-transparent to-ember/30 blur-xl" />
            <div className="relative overflow-hidden rounded-2xl border border-line bg-ink-2 shadow-2xl">
              <div className="flex items-center gap-2 border-b border-line px-4 py-3">
                <span className="h-3 w-3 rounded-full bg-ember" />
                <span className="h-3 w-3 rounded-full bg-amber-400" />
                <span className="h-3 w-3 rounded-full bg-acid" />
                <span className="ml-3 font-mono text-xs text-bone-dim">
                  vipe — build session
                </span>
              </div>
              <div className="space-y-1.5 p-5 font-mono text-[13px] leading-relaxed sm:text-sm">
                <p className="text-bone-dim">$ vipe init --cohort=07</p>
                <p className="text-bone">✓ Bootstrapping your project…</p>
                <p className="text-bone">✓ Assigning senior mentor…</p>
                <p className="text-bone">✓ Wiring AI toolchain…</p>
                <p className="pt-2 text-acid">~/ship-it $</p>
                <p className="text-bone">
                  <span className="text-bone-dim">// your first deploy in</span>{" "}
                  <span className="text-ember">under an hour.</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <span className="text-acid">~/ship-it $</span>
                  <span className="inline-block h-4 w-2.5 animate-blink bg-acid align-middle" />
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
