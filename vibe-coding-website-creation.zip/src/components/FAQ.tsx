import { useState } from "react";
import { Reveal } from "./Reveal";

const FAQS = [
  {
    q: "Do I need prior coding experience?",
    a: "No. Our Front-End Intensive starts from absolute zero. We meet you where you are and move at a pace that builds real confidence — not just memorized syntax.",
  },
  {
    q: "How much time should I commit per week?",
    a: "We recommend 15–20 hours per week: live sessions, mentor pairing, and hands-on project work. Many of our students balance it with part-time work.",
  },
  {
    q: "What if I fall behind?",
    a: "You won't be left behind. Every session is recorded, and mentors flag at-risk learners early so we can course-correct before things snowball.",
  },
  {
    q: "Is there really a job guarantee?",
    a: "Our Cohort track includes an outcomes guarantee: complete the curriculum and the career track, and if you don't land a qualifying role within 6 months, we refund your tuition.",
  },
  {
    q: "Do I get lifetime access to materials?",
    a: "Yes. Studio and Cohort members keep lifetime access to the curriculum, including all future updates as the tooling and AI landscape evolve.",
  },
  {
    q: "Can my company sponsor me?",
    a: "Absolutely. Our Team plan is built for organizations, and we provide invoicing, PO support, and reporting for L&D and talent teams.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="border-t border-line bg-ink-2/40 px-5 py-24 sm:px-8 sm:py-32">
      <div className="mx-auto max-w-3xl">
        <Reveal>
          <div className="mb-12 text-center">
            <span className="font-mono text-sm font-medium uppercase tracking-widest text-acid">
              // FAQ
            </span>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
              Questions, answered.
            </h2>
          </div>
        </Reveal>

        <div className="space-y-3">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={item.q} delay={i * 60}>
                <div className="overflow-hidden rounded-2xl border border-line bg-ink-2/60">
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left sm:px-6"
                    aria-expanded={isOpen}
                  >
                    <span className="font-display text-lg font-semibold">
                      {item.q}
                    </span>
                    <span
                      className={`relative grid h-6 w-6 shrink-0 place-items-center rounded-full border border-line transition-all duration-300 ${
                        isOpen ? "rotate-45 border-acid bg-acid text-ink" : "text-bone-dim"
                      }`}
                    >
                      <svg
                        viewBox="0 0 24 24"
                        className="h-3.5 w-3.5"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth={2.5}
                        strokeLinecap="round"
                      >
                        <path d="M12 5v14M5 12h14" />
                      </svg>
                    </span>
                  </button>
                  <div
                    className={`grid transition-all duration-300 ${
                      isOpen
                        ? "grid-rows-[1fr] opacity-100"
                        : "grid-rows-[0fr] opacity-0"
                    }`}
                  >
                    <div className="overflow-hidden">
                      <p className="px-5 pb-5 leading-relaxed text-bone-dim sm:px-6">
                        {item.a}
                      </p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
