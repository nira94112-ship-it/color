import { useState } from "react";
import { Reveal } from "./Reveal";

const PLANS = [
  {
    name: "Studio",
    price: 299,
    desc: "For the self-starter who wants structure and accountability.",
    features: [
      "Full self-paced curriculum",
      "Community Discord access",
      "Project reviews (async)",
      "Lifetime content updates",
      "Certificate of completion",
    ],
    cta: "Start Studio",
    featured: false,
  },
  {
    name: "Cohort",
    price: 899,
    desc: "Our flagship. Live mentors, real feedback, job outcomes.",
    features: [
      "Everything in Studio",
      "Weekly 1:1 senior pairing",
      "Live group workshops",
      "Capstone project + demo day",
      "Mock interviews & referrals",
      "Job guarantee track",
    ],
    cta: "Join a cohort",
    featured: true,
  },
  {
    name: "Team",
    price: 2400,
    desc: "Upskill your whole engineering org, on your terms.",
    features: [
      "Everything in Cohort",
      "Custom curriculum",
      "Private Slack channel",
      "Quarterly strategy reviews",
      "Priority mentor routing",
      "Dedicated success lead",
    ],
    cta: "Talk to us",
    featured: false,
  },
];

export function Pricing() {
  const [annual, setAnnual] = useState(true);

  return (
    <section id="pricing" className="px-5 py-24 sm:px-8 sm:py-32">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="mb-12 flex flex-col items-center text-center">
            <span className="font-mono text-sm font-medium uppercase tracking-widest text-acid">
              // Pricing
            </span>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
              Invest in building.
            </h2>
            <p className="mt-4 max-w-md text-bone-dim">
              Pay monthly or save 20% with annual billing.
            </p>

            <div className="mt-7 flex items-center gap-1 rounded-full border border-line bg-ink-2 p-1">
              {[
                { label: "Monthly", value: false },
                { label: "Annual", value: true },
              ].map((opt) => (
                <button
                  key={opt.label}
                  type="button"
                  onClick={() => setAnnual(opt.value)}
                  className={`rounded-full px-5 py-2 text-sm font-semibold transition-all duration-300 ${
                    annual === opt.value
                      ? "bg-acid text-ink"
                      : "text-bone-dim hover:text-bone"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {PLANS.map((plan, idx) => (
            <Reveal key={plan.name} delay={idx * 100}>
              <div
                className={`relative flex h-full flex-col rounded-3xl border p-7 transition-all duration-300 sm:p-8 ${
                  plan.featured
                    ? "border-acid bg-gradient-to-b from-acid/[0.07] to-transparent shadow-[0_0_60px_-20px_var(--color-acid)] md:-translate-y-3"
                    : "border-line bg-ink-2/50 hover:border-bone-dim/40"
                }`}
              >
                {plan.featured && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-acid px-3 py-1 font-mono text-xs font-bold text-ink">
                    MOST POPULAR
                  </span>
                )}

                <h3 className="font-display text-2xl font-bold">{plan.name}</h3>
                <p className="mt-2 min-h-[2.75rem] text-sm text-bone-dim">
                  {plan.desc}
                </p>

                <div className="mt-5 flex items-end gap-1">
                  <span className="font-display text-5xl font-extrabold tracking-tight">
                    ${Math.round(plan.price * (annual ? 0.8 : 1))}
                  </span>
                  <span className="mb-1.5 text-bone-dim">/mo</span>
                </div>
                {annual && (
                  <p className="mt-1 font-mono text-xs text-acid">
                    billed annually · save 20%
                  </p>
                )}

                <ul className="mt-6 flex-1 space-y-3">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm">
                      <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        className="mt-0.5 h-4 w-4 shrink-0 text-acid"
                        stroke="currentColor"
                        strokeWidth={3}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                      <span className="text-bone">{f}</span>
                    </li>
                  ))}
                </ul>

                <a
                  href="#apply"
                  className={`mt-8 flex items-center justify-center gap-2 rounded-full px-5 py-4 text-sm font-bold transition-all duration-300 ${
                    plan.featured
                      ? "bg-acid text-ink hover:scale-[1.02] hover:shadow-[0_0_30px_-6px_var(--color-acid)]"
                      : "border border-line bg-ink text-bone hover:border-acid hover:text-acid"
                  }`}
                >
                  {plan.cta} →
                </a>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
