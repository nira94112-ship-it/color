import { useEffect, useState } from "react";
import { cn } from "../utils/cn";

const LINKS = [
  { label: "Programs", href: "#programs" },
  { label: "Method", href: "#method" },
  { label: "Outcomes", href: "#outcomes" },
  { label: "Pricing", href: "#pricing" },
  { label: "FAQ", href: "#faq" },
];

export function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-line bg-ink/80 backdrop-blur-xl"
          : "border-b border-transparent",
      )}
    >
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8">
        <a href="#top" className="group flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-acid font-display text-lg font-extrabold text-ink transition-transform duration-300 group-hover:rotate-12">
            V
          </span>
          <span className="font-display text-lg font-bold tracking-tight">
            VIPE<span className="text-acid">/</span>CODE
          </span>
        </a>

        <ul className="hidden items-center gap-1 md:flex">
          {LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="rounded-md px-3.5 py-2 text-sm text-bone-dim transition-colors hover:bg-ink-3 hover:text-bone"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden md:block">
          <a
            href="#apply"
            className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-acid px-5 py-2.5 text-sm font-bold text-ink transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_0_30px_-4px_var(--color-acid)]"
          >
            <span className="relative z-10">Apply now</span>
            <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
              →
            </span>
          </a>
        </div>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="grid h-10 w-10 place-items-center rounded-lg border border-line text-bone md:hidden"
          aria-label="Toggle menu"
        >
          <span className="relative block h-3.5 w-5">
            <span
              className={cn(
                "absolute left-0 block h-0.5 w-5 bg-current transition-all duration-300",
                open ? "top-1.5 rotate-45" : "top-0",
              )}
            />
            <span
              className={cn(
                "absolute left-0 top-1.5 block h-0.5 w-5 bg-current transition-all duration-300",
                open ? "opacity-0" : "opacity-100",
              )}
            />
            <span
              className={cn(
                "absolute left-0 block h-0.5 w-5 bg-current transition-all duration-300",
                open ? "top-1.5 -rotate-45" : "top-3",
              )}
            />
          </span>
        </button>
      </nav>

      <div
        className={cn(
          "overflow-hidden border-t border-line bg-ink-2 transition-all duration-[400ms] md:hidden",
          open ? "max-h-96 opacity-100" : "max-h-0 opacity-0",
        )}
      >
        <ul className="space-y-1 px-5 py-4">
          {LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={() => setOpen(false)}
                className="block rounded-lg px-3 py-3 text-bone-dim transition-colors hover:bg-ink-3 hover:text-bone"
              >
                {link.label}
              </a>
            </li>
          ))}
          <li className="pt-2">
            <a
              href="#apply"
              onClick={() => setOpen(false)}
              className="block rounded-lg bg-acid px-3 py-3 text-center font-bold text-ink"
            >
              Apply now →
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
