import { Reveal } from "./Reveal";

const PILLARS = [
  {
    n: "01",
    title: "Ship, don't watch",
    body:
      "Every session ends with working code in your repo. No passive lectures — you build from minute one alongside a senior engineer.",
  },
  {
    n: "02",
    title: "Real mentors, real feedback",
    body:
      "Weekly 1:1 pairing with engineers from top product companies. Your code gets reviewed like it's going to production — because it is.",
  },
  {
    n: "03",
    title: "The AI advantage",
    body:
      "We teach you to leverage modern AI tooling so you move at a speed traditional bootcamps simply can't match.",
  },
  {
    n: "04",
    title: "Your network is the product",
    body:
      "Join a curated cohort of driven builders. Peer reviews, demo days, and alumni hiring loops that keep paying out for years.",
  },
];

const STATS = [
  { value: "92%", label: "land a role within 6 months" },
  { value: "1,200+", label: "builders trained since 2021" },
  { value: "4.9★", label: "average cohort rating" },
  { value: "12", label: "senior mentors on staff" },
];

export function Method() {
  return (
    <section id="method" className="relative overflow-hidden px-5 py-24 sm:px-8 sm:py-32">
      <div className="pointer-events-none absolute right-0 top-1/3 h-[30rem] w-[30rem] rounded-full bg-acid/5 blur-[120px]" />
      <div className="relative mx-auto max-w-7xl">
        <div className="grid grid-cols-1 gap-14 lg:grid-cols-2 lg:gap-20">
          {/* Image side */}
          <Reveal>
            <div className="relative lg:sticky lg:top-28">
              <div className="relative overflow-hidden rounded-3xl border border-line">
                <img
                  src="/images/about.jpg"
                  alt="A developer coding with holographic UI"
                  className="aspect-[4/5] w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/10 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <p className="font-mono text-xs uppercase tracking-widest text-acid">
                    // inside the studio
                  </p>
                  <p className="mt-1 font-display text-2xl font-bold">
                    Live. Hands-on. Unfiltered.
                  </p>
                </div>
              </div>
              <div className="absolute -bottom-6 -right-4 hidden rounded-2xl border border-line bg-ink-2 px-5 py-4 shadow-xl sm:block">
                <p className="font-mono text-xs text-bone-dim">Mentor response</p>
                <p className="font-display text-lg font-bold text-acid">
                  &lt; 2 hours
                </p>
              </div>
            </div>
          </Reveal>

          {/* Text side */}
          <div>
            <Reveal>
              <span className="font-mono text-sm font-medium uppercase tracking-widest text-acid">
                // Our method
              </span>
              <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">
                We don't teach to pass.
                <br />
                <span className="text-bone-dim">We teach to ship.</span>
              </h2>
              <p className="mt-5 max-w-lg text-lg leading-relaxed text-bone-dim">
                Most courses hand you a checklist. We hand you a keyboard and
                someone who's been there. The VIPE method is built on one
                conviction: you learn to code by writing code that matters.
              </p>
            </Reveal>

            <div className="mt-10 space-y-4">
              {PILLARS.map((p, i) => (
                <Reveal key={p.n} delay={i * 90}>
                  <div className="group rounded-2xl border border-line bg-ink-2/50 p-6 transition-all duration-300 hover:border-acid/50 hover:bg-ink-2">
                    <div className="flex gap-5">
                      <span className="font-display text-3xl font-extrabold text-line transition-colors duration-300 group-hover:text-acid/60">
                        {p.n}
                      </span>
                      <div>
                        <h3 className="font-display text-xl font-bold">
                          {p.title}
                        </h3>
                        <p className="mt-2 leading-relaxed text-bone-dim">{p.body}</p>
                      </div>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>

            {/* Stats */}
            <Reveal delay={120}>
              <div
                id="outcomes"
                className="mt-12 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line"
              >
                {STATS.map((s) => (
                  <div key={s.label} className="bg-ink-2 p-6">
                    <div className="font-display text-4xl font-extrabold text-acid">
                      {s.value}
                    </div>
                    <div className="mt-1 text-sm text-bone-dim">{s.label}</div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
