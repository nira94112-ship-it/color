import { useState, type FormEvent } from "react";
import { Reveal } from "./Reveal";

export function ApplyCTA() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
  };

  return (
    <section id="apply" className="relative overflow-hidden px-5 py-24 sm:px-8 sm:py-32">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-0 h-[32rem] w-[32rem] -translate-x-1/2 rounded-full bg-acid/15 blur-[140px]" />
      </div>
      <Reveal className="relative mx-auto max-w-3xl text-center">
        <span className="font-mono text-sm font-medium uppercase tracking-widest text-acid">
          // Ready?
        </span>
        <h2 className="mt-4 font-display text-5xl font-extrabold tracking-tight text-balance sm:text-6xl">
          Build something
          <br className="hidden sm:block" /> people will use.
        </h2>
        <p className="mx-auto mt-6 max-w-lg text-lg text-bone-dim">
          Applications for Cohort 07 are open. Tell us where you are — we'll tell
          you where you can be.
        </p>

        {submitted ? (
          <div className="mx-auto mt-10 max-w-md rounded-2xl border border-acid/40 bg-acid/10 p-6">
            <div className="flex items-center justify-center gap-2 font-display text-xl font-bold text-acid">
              <svg
                viewBox="0 0 24 24"
                className="h-6 w-6"
                fill="none"
                stroke="currentColor"
                strokeWidth={2.5}
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M20 6 9 17l-5-5" />
              </svg>
              You're on the list
            </div>
            <p className="mt-2 text-bone-dim">
              We'll reach out to <span className="text-bone">{email}</span> within
              24 hours.
            </p>
          </div>
        ) : (
          <form
            onSubmit={submit}
            className="mx-auto mt-10 flex max-w-md flex-col gap-3 sm:flex-row"
          >
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@email.com"
              className="flex-1 rounded-full border border-line bg-ink-2 px-5 py-4 text-bone outline-none transition-colors placeholder:text-bone-dim/60 focus:border-acid"
            />
            <button
              type="submit"
              className="rounded-full bg-acid px-7 py-4 font-bold text-ink transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_0_40px_-6px_var(--color-acid)]"
            >
              Apply →
            </button>
          </form>
        )}

        <p className="mt-5 font-mono text-xs text-bone-dim">
          No spam. Unsubscribe anytime.
        </p>
      </Reveal>
    </section>
  );
}
