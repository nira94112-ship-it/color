const EXPLORE = ["Programs", "Method", "Pricing", "Outcomes", "FAQ"];
const CONNECT = ["Discord", "X / Twitter", "GitHub", "LinkedIn", "YouTube"];

export function Footer() {
  return (
    <footer className="border-t border-line bg-ink-2 px-5 pt-16 pb-10 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-5">
          <div className="col-span-2">
            <a href="#top" className="flex items-center gap-2.5">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-acid font-display text-lg font-extrabold text-ink">
                V
              </span>
              <span className="font-display text-lg font-bold tracking-tight">
                VIPE<span className="text-acid">/</span>CODE
              </span>
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-bone-dim">
              An elite, mentor-led coding studio for people who'd rather build
              than watch.
            </p>
            <div className="mt-5 flex gap-2">
              {["X", "GH", "DC", "IN"].map((s) => (
                <a
                  key={s}
                  href="#top"
                  className="grid h-9 w-9 place-items-center rounded-lg border border-line font-mono text-xs text-bone-dim transition-colors hover:border-acid hover:text-acid"
                >
                  {s}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-widest text-bone-dim">
              Explore
            </h4>
            <ul className="mt-4 space-y-2.5">
              {EXPLORE.map((l) => (
                <li key={l}>
                  <a
                    href={`#${l.toLowerCase()}`}
                    className="text-sm text-bone transition-colors hover:text-acid"
                  >
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-widest text-bone-dim">
              Connect
            </h4>
            <ul className="mt-4 space-y-2.5">
              {CONNECT.map((l) => (
                <li key={l}>
                  <a
                    href="#top"
                    className="text-sm text-bone transition-colors hover:text-acid"
                  >
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-widest text-bone-dim">
              Contact
            </h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              <li className="text-bone">hello@vipe.code</li>
              <li className="text-bone-dim">Remote-first · 14 timezones</li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-line pt-7 sm:flex-row">
          <p className="font-mono text-xs text-bone-dim">
            © {new Date().getFullYear()} VIPE/CODE Studio. Built for builders.
          </p>
          <div className="flex gap-5 font-mono text-xs text-bone-dim">
            <a href="#top" className="transition-colors hover:text-bone">
              Privacy
            </a>
            <a href="#top" className="transition-colors hover:text-bone">
              Terms
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
