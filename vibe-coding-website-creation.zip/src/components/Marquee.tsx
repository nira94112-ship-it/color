const ITEMS = [
  "React",
  "TypeScript",
  "Next.js",
  "Node.js",
  "Python",
  "AI Tooling",
  "PostgreSQL",
  "Docker",
  "GraphQL",
  "Tailwind",
  "AWS",
  "Git",
];

export function Marquee() {
  const row = [...ITEMS, ...ITEMS];

  return (
    <div className="relative border-y border-line bg-ink-2 py-5">
      <div className="flex overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_12%,black_88%,transparent)]">
        <div className="flex shrink-0 animate-marquee items-center">
          {row.map((item, i) => (
            <span
              key={i}
              className="flex shrink-0 items-center gap-8 px-8 font-display text-xl font-semibold text-bone-dim/60"
            >
              {item}
              <span className="text-acid">✦</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
