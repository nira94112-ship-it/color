import { Navigation } from "./components/Navigation";
import { Hero } from "./components/Hero";
import { Marquee } from "./components/Marquee";
import { Programs } from "./components/Programs";
import { Method } from "./components/Method";
import { Testimonials } from "./components/Testimonials";
import { Pricing } from "./components/Pricing";
import { FAQ } from "./components/FAQ";
import { ApplyCTA } from "./components/ApplyCTA";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-ink font-mono text-bone selection:bg-acid selection:text-ink">
      <Navigation />
      <main>
        <Hero />
        <Marquee />
        <Programs />
        <Method />
        <Testimonials />
        <Pricing />
        <FAQ />
        <ApplyCTA />
      </main>
      <Footer />
    </div>
  );
}
